USE [msdb]
GO

/****** Object:  Job [DBA_Monitor_SQLInspection_Job]    Script Date: 11/4/2024 9:00:03 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 11/4/2024 9:00:03 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA_Monitor_SQLInspection_Job', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Monitor Discover Job]    Script Date: 11/4/2024 9:00:03 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Monitor Discover Job', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'WAITFOR DELAY ''01:00:00''
IF EXISTS
       (
              SELECT 1 FROM msdb.dbo.sysjobs j INNER JOIN msdb.dbo.sysjobactivity ja ON j.job_id = ja.job_id 
			  INNER JOIN (SELECT TOP 1 session_id FROM msdb.dbo.syssessions ORDER BY agent_start_date DESC) ss
              ON ja.session_id = ss.session_id
              WHERE
                     ja.run_requested_date IS NOT NULL and ja.start_execution_date is not null
                     AND ja.stop_execution_date IS NULL
                     AND j.name = ''DBA_SQLInventoryInspection''
       )
BEGIN
BEGIN TRY
EXEC msdb.dbo.sp_send_dbmail  
    @profile_name = ''SQLDBA'',  
    @recipients = ''myofficialemail@domain.com'',  
    @body = ''DBA-My-SQLDiscovery job which is supposed to finish in 1 minute is still running. Please check it'',  
    @subject = ''DBA-My-SQLDiscovery job is still running. Please Check'' ;
	       
EXEC msdb.dbo.sp_stop_job @job_name=''DBA_SQLInventoryInspection'';
END TRY
BEGIN CATCH
END CATCH
END 

', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

